<?php 
$servername = "localhost";
$username = "root";
$password = "password";
$db = "certbuild";

try {
   
    $conn = mysqli_connect($servername, $username, $password, $db);


    if(isset($_POST["Import"])){
		
		$filename=$_FILES["file"]["tmp_name"];		


		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
	        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {


	           $sql = "INSERT into gechutsav(id,name,sem,branch,event,rank) values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."')";
                   $result = mysqli_query($conn, $sql);
				if(!isset($result))
				{
					echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload CSV File.\");
							window.location = \"geccsv.php\"
						  </script>";		
				}
				else {
					  echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");
						window.location = \"geccsv.php\"
					</script>";
				}
	         }
			
	         fclose($file);	
		 }
	}



 if(isset($_POST["delete"])){
 			$sql = "truncate table gechutsav";
 			$res = mysqli_query($conn,$sql);
 			if($res) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Deleted!</strong>Successfully
		<meta http-equiv="refresh" content="3;url=geccsv.php" />
	</div>

	<?php
}
else {
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry!</strong>Data not deleted
  		<meta http-equiv="refresh" content="2;url=geccsv.php" />
	</div>
	<?php
} 
 }
   if(isset($_POST["Export"])){
		 
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('id', 'Name', 'Sem', 'branch','event','rank'));  
      $query = "SELECT * from gechutsav  ORDER BY id";  
      $result = mysqli_query($conn, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);


 }  
}
catch(exception $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
?>