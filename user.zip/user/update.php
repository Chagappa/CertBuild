<?php 
/*ini_set('display_errors', 1);
                error_reporting (E_ALL);*/
                include('database.php');

if(isset($_GET['usn']))
{
$usn=$_GET['usn'];

$sql="select * from participant where usn like '".$usn."'";
 $result=mysqli_query($conn, $sql);
 $row= mysqli_fetch_assoc($result);
 $id=$row['usn'];
 $name=$row['name'];
 $father=$row['father'];
 $phone=$row['phone'];
 $gender=$row['gender'];
 $email=$row['email'];
 $sem=$row['sem'];
 $branch=$row['branch'];
 $year=$row['year'];
 $college=$row['college'];
 $grade=$row['grade'];
 $event=$row['event'];
 $rank=$row['prize'];
 }
?>

<!DOCTYPE html>
<html>
<head>
<!-- <?php
//include("navbar.php");
?> -->
 <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/w3.css">
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
   <script type="text/javascript" src="../js/jquery.min.js"></script>
	<title>CertificateBuilder</title>
	<style type="text/css">
		.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.container {
    position: relative;
    text-align: center;
    color: white;
}

body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("../img/background10.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
}
.form-inline > * {
   margin:25px 10px;
}

.image-preview-input-title {
    margin-left:2px;
}


/*
.image-preview-input input[type=file] {
  position: absolute;
  top: 0;
  right: 0;
  margin: 0;
  padding: 0;
  font-size: 20px;
  cursor: pointer;
  opacity: 0;
  filter: alpha(opacity=0);
}*/
.image-preview-input {
    position: relative;
  overflow: hidden;
  margin: 0px;    
    color: #333;
    background-color: #fff;
    border-color: #ccc;    
}
.content {
    max-width: 60%;
    margin: auto;
  /*  background: transparent;*/
    padding: 10px;
     height: 100%; 

	</style>
  <script src="script.js"></script>
</head>

<body class="bg">
<br><br>
 <div style="background:transparent !important;border:solid thin black;border-radius: 10px;" class="container-fluid" align="center">
  <h1 style="color: #ffffff"><b>UPDATE CSV</b></h1>
  <p style="color: #000000"><b>Participant Details</b></p>
</div><br>
<div class="content" style="opacity: 0.7;"><br><br>
<form  class="form-horizontal w3-animate-zoom" action="updatedata.php" method="POST">
    <div class="form-group">
        <label class="control-label col-sm-2" for="usn">USN or ID:</label>
        <div class="col-sm-9"> 
            <input type="text" name="usn" class="form-control" id="usn" placeholder="Enter USN or ID" value="<?php echo "$usn"; ?>" required="" readonly>
        </div>
    </div><br>

     <div class="form-group">
        <label class="control-label col-sm-2" for="usn">USN or ID:</label>
        <div class="col-sm-9"> 
            <input type="text" name="id" class="form-control" id="id" placeholder="Enter USN or ID" value="<?php echo "$id"; ?>" required="">
        </div>
    </div><br>
 <div class="form-group">
 <label class="control-label col-sm-2" for="name">Name:</label> 
 
     <div class="col-sm-9">
      <input type="text" name="name" class="form-control" id="name" placeholder="Enter Your Name" value="<?php echo "$name"; ?>" required=""> 
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="name">Gender:</label>
 <div class="col-sm-9"> 
  <label class="radio-inline">
      <input type="radio" name="gender" value="male" <?php if($gender== 'male'||$gender=='Male')  echo "checked"; ?> id="gender" required="">Male
    </label>
    <label class="radio-inline">
      <input type="radio" name="gender" value="female" <?php if($gender== 'female'||$gender=='Female')  echo "checked"; ?> id="gender" required="">Female
    </label>
   
    </div>
 </div><br>

  <div class="form-group">
 <label class="control-label col-sm-2" for="father">Father Name:</label>
     <div class="col-sm-9">
      <input type="text" name="father" class="form-control" id="father" placeholder="Enter Your father name" value="<?php echo "$father"; ?>"">
     </div>

 </div><br>
  <div class="form-group">
 <label class="control-label col-sm-2" for="phone">Phone Number:</label>
     <div class="col-sm-9">
      <input type="Number" name="phone" class="form-control" id="phone" placeholder="Enter Your Phone Number" value="<?php echo "$phone"; ?>" required="">
       
     </div>
 </div><br>
 <div class="form-group">
    <label class="control-label col-sm-2" for="email">Email:</label>
    <div class="col-sm-9">
      <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo "$email"; ?>" required="">
    </div>
  </div><br>
  <div class="form-group">
 <label class="control-label col-sm-2" for="college">College:</label>
     <div class="col-sm-9">
      <input type="text" class="form-control" id="college" name="college" placeholder="Enter college name" value="<?php echo "$college"; ?>"required=""> 
       
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="sem">Sem:</label>
     <div class="col-sm-9">
      <input type="text" class="form-control" id="sem" name="sem" placeholder="Enter semester" value="<?php echo "$sem"; ?>" required=""> 
       
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="branch">Branch:</label>
     <div class="col-sm-9">
<select name="branch" class="form-control" id="branch" required="">
  <option value="<?php echo $branch; ?>"><?php echo $branch; ?></option>
  <option value="cse">CSE</option>
  <option value="ece">ECE</option>
  <option value="mech">MECH</option>
  <option value="civil">CIVIL</option>
  <option value="eee">EEE</option>
</select>
 </div>
 </div><br>

<div class="form-group">
 <label class="control-label col-sm-2" for="year">Year:</label>
  <div class="col-sm-9">
    <input type="number" name="year" class="form-control" id="year" placeholder="Enter year Ex:2015" value="<?php echo "$year"; ?>">
      </div>
 </div><br><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="grade">Grade:</label>
     <div class="col-sm-9">
      <input type="text" name="grade" class="form-control" id="grade" placeholder="Enter Your Grade Ex:A" value="<?php echo "$grade"; ?>"> 
     </div>
 </div><br>

<div class="form-group">
 <label class="control-label col-sm-2" for="event">Event:</label>
     <div class="col-sm-9">
      <input type="text" name="event" class="form-control" id="event" placeholder="Enter Event" required="" value="<?php echo "$event"; ?>">
     </div>
 </div><br>

 <div class="form-group">
 <label class="control-label col-sm-2" for="rank" >Rank:</label>
     <div class="col-sm-9">
<select name="rank" class="form-control" id="rank" required="">
  <option value="<?php echo $rank; ?>"><?php echo $rank; ?></option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
</select>
 </div>
 </div><br>
 
 <div class="container-fluid" align="center">
     <button type="submit" class="btn btn-info btn-lg" name="submit">Update</button>
 </div><br><br>
</form>
</div>
 </div>
</form>
</div>



</body>
</html>