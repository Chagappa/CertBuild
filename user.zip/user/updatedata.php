<!DOCTYPE html>
<html>
<head>
	<title>UpdateCSV</title>

	<link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/w3.css">
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
   <script type="text/javascript" src="../js/jquery.min.js"></script>
</head>
<body>
<?php 

include('database.php');

if(isset($_POST['submit'])){

 $usn=$_POST['usn'];
 $id=$_POST['id'];
 $name=$_POST['name'];
 $father=$_POST['father'];
 $phone=$_POST['phone'];
 $gender=$_POST['gender'];
  $sem=$_POST['sem'];
 $email=$_POST['email'];
 $branch=$_POST['branch'];
 $year=$_POST['year'];
 $college=$_POST['college'];
 $grade=$_POST['grade'];
 $event=$_POST['event'];
 $rank=$_POST['rank'];

$update="update participant set usn='".$id."',name='".$name."',gender='".$gender."',email='".$email."',phone='".$phone."',grade='".$grade."',prize='".$rank."',branch='".$branch."',event='".$event."',father='".$father."',college='".$college."',year='".$year."',sem='".$sem."' where usn like '".$usn."'";

$res = mysqli_query($conn,$update);
if(mysqli_affected_rows($conn)>0) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Success!</strong> Your response has been successfully updated.
		<meta http-equiv="refresh" content="2;url=disp.php" />
	</div>

	<?php
}
else {
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry!</strong>Nothing is Updated.Thank you
  		<meta http-equiv="refresh" content="2;url=disp.php" />
	</div>
	<?php
}
}
?>
</body>
</html>



