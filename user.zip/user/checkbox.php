<?php
include('database.php');
//echo "connected suceessfully";
$sql="truncate table checkbox";
	mysqli_query($conn,$sql);
	if(isset($_POST['submit'])) { 

		$usn=$_POST['check'];
		for ($i=0; $i<sizeof($usn);$i++) {
			echo "$usn[$i]";
		$sql="insert into checkbox(usn) values('$usn[$i]')";
		$res=mysqli_query($conn,$sql);
		if(mysqli_affected_rows($conn)>0) {
	?><br><br><br>
	<div class="alert alert-success">
  		<strong>Success!</strong> Your response has been successfully recorded.Thank you.
		<meta http-equiv="refresh" content="6;url=disp.php" />
	</div>

	<?php
}
else {
	?>
	<br><br><br>
	<div class="alert alert-danger">
  		<strong>Sorry!</strong> Please try to re enter your details. Please make sure credentials such as id and email are unique
  		<meta http-equiv="refresh" content="7;url=disp.php" />
	</div>
	<?php
} 
	}
	}

?>

