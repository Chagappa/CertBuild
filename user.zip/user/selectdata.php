<!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style type="text/css">
 		
 #page-loader {
position: relative;
top: 0;
bottom: 0;
left: 0;
right: 0;
z-index: 10000;
display: none;
text-align: center;
width: 100%;
padding-top: 25px;
background-color: rgba(255, 255, 255, 0.7);
}
.bg {
    /* The image used */
    background-image: url("../img/background9.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
}
 	</style>
 </head>
 <body class="bg">
 	<?php
 		include('bootlink.php');
 		include('navbar.php');
 	?>
  <div id="page-loader">
    <h3 style="color: green;">Loading page...</h3> 	
</div><br><br><br>
<div class="row">
<?php

$design=$_GET['design'];

for ($i=1; $i <100; $i++) { 
	if($design==sp.$i)
	{
		?>
		<div align="center" class="col-sm-6"><a href="samsport.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
		<?php
		$selected=$design;
		break;
	}
	elseif ($design==cul.$i) {
		?>
		<div align="center" class="col-sm-6"><a href="samcul.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
		<?php
		$selected=$design;
		break;

	}
	elseif ($design==course.$i) {
		?>
		<div align="center" class="col-sm-6"><a href="samcourse.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
		<?php
		$selected=$design;
		break;
	}
	elseif ($design==bestout.$i) {
		?>
		<div align="center" class="col-sm-6"><a href="sambestout.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
		<?php
		$selected=$design;
		break;
	}
	elseif ($design==other.$i) {
		?>
		<div align="center" class="col-sm-6"><a href="samother.php?id=<?php echo "$i"; ?>"  onclick="javascript:document.getElementById('page-loader').style.display='block';"><p><button class="btn btn-primary btn-lg">Selected Design</button></p></a></div>
		<?php
		$selected=$design;
		break;
	}
}

 ?>

	<div align="center" class="col-sm-6"><a href="design.php"><p><button class="btn btn-success btn-lg">Change design</button></p></a></div>
 </div><br><br>
<div class="alert alert-info" align="center">
  <strong><h3>Select Participants Data by below options.</h3></strong>
</div><br><br>
<div class="row">
<div align="center" class="col-sm-6"><a href="csv/csv.php?design=<?php echo "$selected";?> "><p><button class="btn btn-success btn-lg">CSV(.csv format)</button></p></a></div>
<div align="center" class="col-sm-6"><a href="insert.php?design=<?php echo "$selected";?>"><p><button class="btn btn-info btn-lg">Individual entry</button></p></a></div>
</div>
 </body>
 </html>