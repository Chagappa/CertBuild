<?php
include('config.php');
?>  
<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<style type="text/css">
   .navbar {
    margin-bottom: 0;
    background-color:transparent;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;

}
html {
  scroll-behavior: smooth;
}

.navbar li a, .navbar .navbar-brand {
    color: #ffffff !important;
}

.navbar-nav li a:hover, .navbar-nav li.active a {
    color: #ffffff !important;
    background-color: transparent !important;
}

.navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
}
 

hr.style1 {
  height: 10px;
  border: 0;
  box-shadow:  0 10px 10px -10px black inset;
}

hr.style2 { 
  height: 30px; 
  border-style: solid; 
  border-color: #8c8b8b; 
  border-width: 1px 0 0 0; 
  border-radius: 20px; 
} 
hr.style2:before { 
  display: block; 
  content: ""; 
  height: 30px; 
  margin-top: -31px; 
  border-style: solid; 
  border-color: #8c8b8b; 
  border-width: 0 0 1px 0; 
  border-radius: 20px; 
}
footer {
    font-family: Open Sans;
      background-color:#004f74;
      color: #f5f5f5;
      padding: 32px;
  }
  footer a {
      color: #f5f5f5;
  }
  footer a:hover {
      color: #777;
      text-decoration: none;
  }  
</style>
 
 <nav class="navbar navbar-default navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><b>CertiBuilder</b></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="csv/csv.php"><b>ADD_CSV</b></a></li>
        <li><a href="insert.php"><b>ADD_PARTICIPANT</b></a></li>
        <li><a href="disp.php"><b>VIEW_PARTICIPANTS</b></a></li>

         <!--  <li><a href="login.php"><b>UPDATE_DETAILS</b></a></li>
          <li><a href="login.php"><b>CHANGE_PASSWORD</b></a></li> -->
         <!--  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span><b>LOGOUT</b></a></li> -->

       <li class="dropdown">
       <a class="dropdown-toggle" data-toggle="dropdown" href="#"><b>Hello <?php echo "$username";?></b><span class="caret"></span></a>
        <ul class="dropdown-menu" style="background-color:#004f74;">
          <li><a href="# "><b>Update Profile</b></a></li>
          <li><a href="logout.php"><b>Logout</b></a></li> 
        </ul>
      </li>
      </ul>
      <ul class="nav navbar-nav navbar-center">
        <li><a href="http://www.gechassan.ac.in" target="_blank"><b>GECH</b></a></li>
      </ul>
    </div>
  </div>
</nav> 
  <hr class="style1">
</html>
