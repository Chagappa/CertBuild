<!DOCTYPE html>
<html>

<title>CertificateBuilder</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style type="text/css">
.content {
    max-width: 500px;
    margin: auto;
  /*  background: transparent;*/
  opacity: 0.7;
    padding: 10px;
     height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
.bg {
    /* The image used */
    background-image: url("img/background9.jpg");
    /* Full height */
    height: 100%; 
/*    padding-top: 8%;*/
    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
  
<body class="bg">
  <?php
include('navbar.php');
?>
<div class="content w3-animate-zoom" style="padding-top: 140px">
<div class="w3-card-4" style="padding-top: 8%;border:solid thin black;border-radius: 10px;border-color: green;box-shadow: 1px 1px 90px #fff;">
  <div class="w3-container w3-center ">
    <h2><b  style="color: #ffffff">LOGIN</b></h2><br>
  </div>
  <form class="w3-container" action="logincheck.php" method="POST">
    <p>      
    <label class="w3-text-black"><b  style="color: #ffffff">Username</b></label>
    <input class="w3-input w3-border w3-hover-grey w3-round-xxlarge" name="username" type="text" required="" <?php if (isset($_get['error'])) {
                 $Username=$_POST['error'];
                 echo "value='".$username."'";
            } ?>/></p><br><br>

    <p>   
     <?php if (isset($_POST['error'])) {

    echo "<label class='error'>Wrong username/password</label>";
}
  ?>   
    <label class="w3-text-black" ><b  style="color: #ffffff">Password</b></label>
    <input class="w3-input w3-border w3-hover-grey w3-round-xxlarge" name="password" type="password" required=""></p><br>
   	<p class="w3-center">
   	<button class="w3-button w3-blue w3-round-xxlarge w3-large w3-hover-green" name="submit">GO-></button></p><br>
  </form>
</div>
</div>
</body>
</html> 