<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<style type="text/css">
   .navbar {
    margin-bottom: 0;
    background-color:transparent;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;

}
html {
  scroll-behavior: smooth;
}

.navbar li a, .navbar .navbar-brand {
    color: #ffffff !important;
}

.navbar-nav li a:hover, .navbar-nav li.active a {
    color: #ffffff !important;
    background-color: transparent !important;
}

.navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
}
 

hr.style1 {
  height: 10px;
  border: 0;
  box-shadow:  0 10px 10px -10px black inset;
}

hr.style2 { 
  height: 30px; 
  border-style: solid; 
  border-color: #8c8b8b; 
  border-width: 1px 0 0 0; 
  border-radius: 20px; 
} 
hr.style2:before { 
  display: block; 
  content: ""; 
  height: 30px; 
  margin-top: -31px; 
  border-style: solid; 
  border-color: #8c8b8b; 
  border-width: 0 0 1px 0; 
  border-radius: 20px; 
}
footer {
    font-family: Open Sans;
      background-color:#004f74;
      color: #f5f5f5;
      padding: 32px;
  }
  footer a {
      color: #f5f5f5;
  }
  footer a:hover {
      color: #777;
      text-decoration: none;
  }  
</style>

<body>

<nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top">
  <div class="container-fluid"> 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand"  href="index.php"><b>CertiBuilder</b></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php#about" style="font-size: 15px"><b>About</b></a></li>
         <li><a href="https://gechassan.ac.in" style="font-size: 15px"><span class="glyphicon glyphicon-home"></span><b>GECH</b></a></li>
         <li><a href="login.php" style="font-size: 15px"><span class="glyphicon glyphicon-log-in"></span><b>Login</b></a></li>
      </ul>
     <!--  <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul> -->
    </div>

  </div>
     <hr class="style1">
</nav>
