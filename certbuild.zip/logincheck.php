<?php 

/*ini_set('display_errors', 1);
error_reporting (E_ALL);
echo "My first PHP script!";*/
$servername ="localhost";
$username= "root";
$password= "Password@123";
$dbname = "certbuild";



$conn = mysqli_connect($servername, $username, $password,$dbname );
if ($conn->connect_error) {
    die("Connection failed: ");
}
//echo "connected suceessfully";
	if(isset($_POST['submit']) && !(is_null($_POST['username']) || is_null($_POST['password']))    &&  !(empty($_POST['username']) || empty($_POST['password']))) { 

$username=strip_tags($_POST['username']);
$username=mysqli_real_escape_string($conn,$_POST['username']);
$password=strip_tags($_POST['password']);
$password=mysqli_real_escape_string($conn,$_POST['password']);
/*include('salt.php');
$pass= hash('gost', $password.$salt);
/*echo "hgjg$username";*/
$sql="select * from login where username like '$username'";
mysqli_select_db($conn,$dbname);
$query=mysqli_query($conn, $sql);
                    if($query){
                $row= mysqli_fetch_assoc($query);
                  $dbusername=$row['username'];
          $dbusername=strip_tags($dbusername);
                $dbpassword=$row['password'];
        $dbpassword=strip_tags($dbpassword);
            }

            if($username== $dbusername && $password== $dbpassword){
                session_start();
                    $_SESSION['expire'] = time() + 15*60;
                    $_SESSION['login_user']=$username;
                    $_SESSION['prev'] = $prev;
                    $_SESSION['logged']= true;

              header('Location:user/index.php');
              }

                else{
                      $_SESSION['logged']=false;
                header("location:login.php?error=".$username."");
            }
      }
      else{
               //       $_SESSION['logged']=false;
                header("location:login.php?error=ThereisAnError");
              }

 ?>



