<!DOCTYPE html>
<html>
<head>
	<title>certificate</title>
      <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/html2canvas.js"></script>
  <script type="text/javascript" src="js/jspdf.min.js"></script>
  <script  src="js/standard_fonts_metrics.js"></script> 
<script type="text/javascript" src="js/split_text_to_size.js"></script>               
<script type="text/javascript" src="js/from_html.js"></script>
<script type="text/javascript" src="js/jspdf.debug.js"></script>

<script language="javascript" type="text/javascript">

          function genPDF() {
          var DocumentContainer = document.getElementById('back');
          var WindowObject = window.open('', 'PrintWindow','width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes');
           var strHtml = "<html>\n<head>\n <link rel=\"stylesheet\" type=\"text/css\"  href=\"test.css\">\n</head><body><div style=\"testStyle\">\n" + DocumentContainer.innerHTML + "\n</div>\n</body>\n</html>";

    WindowObject.document.writeln(strHtml);
        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();
    }
            
    </script>
<style type="text/css">


  #back
  {
    background-image: url('img/backgroundcerti.jpg');
     width: 80%;
    height: auto;
  background-position: center; 
  background-repeat: no-repeat; 
  background-size: cover;
  }
</style>
</style>
</head>
<?php
/*ini_set('display_error', 1);
error_reporting(E_ALL);
echo "my first php script";*/
$servername="localhost";
$username="root";
$password="password";
$dbname="certbuild";

$conn=mysqli_connect($servername,$username,$password,$dbname);
if ($conn->connect_error) {
    die("connection failed: ");
}
$sql="select * from participant";
$query=mysqli_query($conn,$sql);
if ($query) {
       $row=mysqli_fetch_assoc($query);
      $name=$row['name']; 
      $course=$row['branch'];
      $grade=$row['grade']; 
}
      
?>
<body>
<div class="container-fluid" style="padding:20px; text-align:center; border: 10px solid #787878;">
<div class="container-fluid" style="padding:20px; text-align:center; border: 5px solid #787878;" id="back">
       <span style="font-size:50px; font-weight:bold">Certificate of Completion</span><br><br>

       <span style="font-size:25px"><i>This is to certify that</i></span>
       <br><br>
       <span style="font-size:30px"><b><?php echo $name;?></b></span><br/><br/>
       <span style="font-size:25px"><i>has completed the course</i></span> <br/><br/>
       <span style="font-size:30px"><?php echo $course; ?></span> <br/><br/>
       <span style="font-size:20px">with score of <b><?php echo $grade; ?></b></span> <br/><br/><br/><br/>
       <span style="font-size:25px"><i>dated</i></span><br>
      <span style="font-size:30px"><b><?php echo "".date("Y-m-d").""; ?></b></span>
</div>
<div class="container-fluid">
<a href="javascript:genPDF();"><button  class="w3-button w3-aqua w3-round-xxlarge w3-xlarge w3-hover-green" style="float: right;"><b>Print</b></button></a>
<a href="user/index.php"><button class="w3-button w3-blue w3-round-xxlarge w3-xlarge w3-hover-red" style="position: absolute; left: 60px;"><b>Back</b></button></a>
</div>
</div>
<!-- <button id="cmd">Print Certificate</button> -->
</body>
</html>