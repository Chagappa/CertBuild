<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>CertificateBuilder</title>
	<style type="text/css">
		.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.container {
    position: relative;
    text-align: center;
    color: white;
}

body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/background6.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}


	</style>
</head>
<body class="bg" data-spy="scroll" data-target=".navbar" data-offset="50">
<?php 
    include('navbar.php');
?>
<!-- <hr class="style1"> -->
	<div>
		
		<div class="centered" style="text-align: center; color: #ffffff"><h1><b>Create Your Own Certificate With CertificateBuilder</b></h1><br> 	
			 <a href="login.php" style="color: #ffffff"><button type="button" class="btn btn-lg" style="background-color:#004f74"><b>New Design</b></button></a>
		</div>
    </div>
 <section style="padding-top: 600px">
   <div class="jumbotron text-center container-fluid" id="about" style="text-align: justify; padding-left: 2%;padding-right: 2%; padding-top: 35px;font-size: 17px">
    <br>
  <h2 align="center">About us</h2>This is an Certificate Building Application.There are a lot of reasons why you might want to give someone a certificate: to award a student for their academic achievements, to
acknowledge an employee who demonstrated company values, to congratulate participants in a charity event, and a whole lot more. With certificate builder you can quickly design professional certificates and award certificates for work, school, sports and more. Quickly
and easily customize them with your own!
By creating your own certificate, you can customize the design to
fit each occasion, incorporate your branding, and reuse custom templates
for different occasions. Showcase your brand’s creativity and values with
a beautiful certificate design.<br>
</div> 
</section>  

<footer>
  <div class="col-md-4">
    <a href="http://gechassan.ac.in"><p><span class="glyphicon glyphicon-globe"></span>GECH</p></a>
  </div>
<div class= "col-md-4" align="center">
<!-- <a href="https://facebook.com/fsmkcamp/" class="btn btn-sm btn-social-icon btn-facebook " ><span class="fa fa-facebook"></span></a>
<a href="http://twitter.com/fsmk_org" class="btn btn-sm btn-social-icon btn-twitter"><span class="fa fa-twitter"></span></a>
<a href="http://github.com/fsmk" class="btn btn-sm btn-social-icon btn-github"><span class="fa fa-github"></span></a> -->
<p>CET Help Line Center: 08172-240150</p>
</div>
<div class="col-md-4" align="right" >
  <p>Government Engineering College,Hassan</p>
</div>
<br>
<div class="col-md-12" align="right" style=" ">
<a href="https://www.google.com/maps?ll=13.009796,76.121789&z=14&t=m&hl=en&gl=US&mapclient=embed&cid=5853986121243383830"><p style="text-align: right; font-size: 9px;">Location:Dairy Circle,Hassan</p>
</div>
</footer>
</body>
</html> 